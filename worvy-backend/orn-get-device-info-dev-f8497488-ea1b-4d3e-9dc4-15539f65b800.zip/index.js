let AWS = require('aws-sdk');
let $db = new AWS.DynamoDB();
const DynamodbFactory = require('@awspilot/dynamodb')
let DynamoDB = new DynamodbFactory($db);

exports.handler = function (event, context) {
    console.log(">>>>>>>>>>>>>>>>",event)
    // let deviceid = event.querystring.params.deviceid ? event.querystring.params.deviceid : ''
    let deviceid = 'mydev'
    DynamoDB
        .table('device-data-info')
// 		.select( DynamoDB.ALL )
        // .select(['partitionKey', 'sortKey', 'nested_object.nested_attribute', 'array_mixed[1]', 'array_mixed[5].key'])
        // .addSelect('created_at')
        .where('deviceid').eq(deviceid)
        // .descending()
        // .limit(100)
        // .consistent_read()
        .get(function (err, data, raw) {
            // console.log("LastEvaluatedKey = ", this.LastEvaluatedKey)
            // console.log(err, data)
            // console.log("raw data ", raw);
            // return data;
            return context.succeed(data);

        });
};
